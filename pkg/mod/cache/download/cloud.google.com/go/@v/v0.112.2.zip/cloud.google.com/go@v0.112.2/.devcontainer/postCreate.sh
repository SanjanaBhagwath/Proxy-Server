echo "Post Create Starting"

go version
go mod tidy
