# auth

This module is currently EXPERIMENTAL and under active development. It is not
yet intended to be used.
