# GCP Resource detection library

This is a library intended to be used by Upstream OpenTelemetry resource detectors.  It exists within this repository to allow for integration testing of the detection functions in real GCP environments.
