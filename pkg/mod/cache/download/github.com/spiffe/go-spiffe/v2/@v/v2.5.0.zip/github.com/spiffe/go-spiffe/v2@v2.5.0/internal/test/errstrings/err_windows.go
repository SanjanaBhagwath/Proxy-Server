//go:build windows
// +build windows

// OS specific error strings
package errstrings

var (
	FileNotFound = "The system cannot find the file specified."
)
