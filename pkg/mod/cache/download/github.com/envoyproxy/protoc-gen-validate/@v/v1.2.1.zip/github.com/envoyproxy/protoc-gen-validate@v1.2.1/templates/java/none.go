package java

const noneTpl = `// no validation rules for {{ simpleName .Field }}
`
