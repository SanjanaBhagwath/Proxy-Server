# Go PKCS #11

[![Go Reference](https://pkg.go.dev/badge/github.com/google/go-pkcs11/pkcs11.svg)](https://pkg.go.dev/github.com/google/go-pkcs11/pkcs11)

A Go package for loading PKCS #11 modules.

WARNING: The API exposed by this package is currently experimental and will
change.
