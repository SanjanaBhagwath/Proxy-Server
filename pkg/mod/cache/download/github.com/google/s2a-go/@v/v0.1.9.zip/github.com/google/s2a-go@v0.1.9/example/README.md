This example implements a gRPC Go Echo client and server which use self-signed X.509 certificates and s2av2TransportCreds (implementation of
TransportCredentials interface) to establish an mTLS connection.
